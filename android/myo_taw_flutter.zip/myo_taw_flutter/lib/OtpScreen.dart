import 'package:flutter/material.dart';
import 'helper/MyoTawConstant.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'main.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:dio/dio.dart';
import 'helper/ServiceHelper.dart';
import 'model/UserModel.dart';
import 'package:connectivity/connectivity.dart';
import 'helper/SharePreferencesHelper.dart';
import 'package:myotaw/Database/UserDb.dart';

class OtpScreen extends StatefulWidget {
  String _phNo, _regionCode;
  OtpScreen(this._phNo, this._regionCode);
  @override
  _OtpScreenState createState() => _OtpScreenState(this._phNo, this._regionCode);
}

class _OtpScreenState extends State<OtpScreen> {
  String  _regionCode, _platForm, _phNo, _code;
  bool _isInitialized, _showLoading = false;
  bool _isCon = false;
  Response response;
  UserModel _userModel;
  Sharepreferenceshelper _sharePrefHelper = new Sharepreferenceshelper();
  UserDb _userDb = UserDb();
  TextEditingController _otpCodeController = new TextEditingController();

  _OtpScreenState(this._phNo, this._regionCode);
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _sharePrefHelper.initSharePref();
    _smsStartListening();
  }

  _smsStartListening() async{
    _verifyOtp(_code);
  }

  void _logIn()async{
    setState(() {
      _showLoading = true;
    });
    String fcmtoken = 'doRMZhpJvpY:APA91bG4XW1tHVIxf_jbUAT8WekmgAlDd4JZAKQm9o3DUDYqVCoWmmmaznHTgbyMxXXNZZ9FwFewZz5DcSE7ooxdLZAPdUDXeD7iD16IUP1P0DwGzzWlsRxovB1zq16FHKUcdgDGud4t';
    response = await ServiceHelper().userLogin(_phNo, _regionCode, fcmtoken, _platForm);
    var result = response.data;
    setState(() {
      _showLoading = false;
    });
    if(response.statusCode == 200){
      if(result != null){
        _userModel = UserModel.fromJson(result);
        _sharePrefHelper.setLoginSharePreference(_userModel.uniqueKey, _userModel.phoneNo, _regionCode);
        await _userDb.openUserDb();
        await _userDb.insert(_userModel);
        await _userDb.closeUserDb();
        Fluttertoast.showToast(msg: 'Login Success', backgroundColor: Colors.black.withOpacity(0.7));
        if(_userModel.name != null){
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => MainScreen(_userModel)));
        }else{

        }
      }else{
        Fluttertoast.showToast(msg: 'နောက်တစ်ကြိမ်လုပ်ဆောင်ပါ။', backgroundColor: Colors.black.withOpacity(0.7));
      }
    }else{
      Fluttertoast.showToast(msg: 'နောက်တစ်ကြိမ်လုပ်ဆောင်ပါ။', backgroundColor: Colors.black.withOpacity(0.7));
    }
  }

  _verifyOtp(String code) async{
    setState(() {
      _showLoading = true;
    });
    response = await ServiceHelper().verifyOtp(_phNo, code);
    var result = response.data;
    if(response.statusCode == 200){
      if(result != null){
        if(result['code'] == '002'){
          _logIn();
        }
      }else{
        Fluttertoast.showToast(msg: 'နောက်တစ်ကြိမ်လုပ်ဆောင်ပါ။', backgroundColor: Colors.black.withOpacity(0.7));
      }
    }else{
      Fluttertoast.showToast(msg: 'နောက်တစ်ကြိမ်လုပ်ဆောင်ပါ။', backgroundColor: Colors.black.withOpacity(0.7));
    }
  }

  _checkCon()async{
    var conResult = await(Connectivity().checkConnectivity());
    if (conResult == ConnectivityResult.none) {
      _isCon = false;
    }else{
      _isCon = true;
    }
    print('isCon : ${_isCon}');
  }

  Widget modalProgressIndicator(){
    return Center(
      child: Card(
        child: Container(
          width: 220.0,
          height: 80.0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(margin: EdgeInsets.only(right: 30.0),
                  child: Text('Loading......',style: TextStyle(fontSize: FontSize.textSizeNormal, color: Colors.black))),
              CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(MyColor.colorPrimary))
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: ModalProgressHUD(
          inAsyncCall: _showLoading,
          progressIndicator: modalProgressIndicator(),
          child: Center(
            child: Stack(
              children: <Widget>[
                //color primary bg
                Container(
                  color: MyColor.colorPrimary,
                  width: double.maxFinite,
                  height: 300,
                ),
                //login card
                Container(
                  width: double.maxFinite,
                  margin: EdgeInsets.only(bottom: 50),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.asset("images/myotaw_icon_white.png", width: 90, height: 80,),
                      Container(
                        margin: EdgeInsets.all(30),
                        child: Card(
                          child: Container(
                            margin: EdgeInsets.all(30),
                            child: Column(
                              children: <Widget>[
                                Container(
                                    margin: EdgeInsets.only(bottom: 30),
                                    child: Text(MyString.txt_enter_otp, style: TextStyle(fontSize: FontSize.textSizeExtraNormal, color: MyColor.colorPrimary), textAlign: TextAlign.center,)),
                                Container(
                                  margin: EdgeInsets.only(bottom: 30.0),
                                  padding: EdgeInsets.only(left: 10.0, right: 10.0),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(7.0),
                                      border: Border.all(color: MyColor.colorPrimary, style: BorderStyle.solid, width: 0.80)
                                  ),
                                  child: TextField(
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      suffixIcon: Icon(Icons.phone_android, color: MyColor.colorPrimary,),
                                      hintText: 'xxxxxx',
                                    ),
                                    cursorColor: MyColor.colorPrimary,
                                    controller: _otpCodeController,
                                    style: TextStyle(fontSize: FontSize.textSizeNormal, color: MyColor.colorTextBlack,),
                                    keyboardType: TextInputType.phone,
                                  ),
                                ),
                                Container(
                                  width: double.maxFinite,
                                  height: 45.0,
                                  child: RaisedButton(onPressed: () async{
                                    await _checkCon();
                                    if(_isCon){
                                      if(_otpCodeController.text.isNotEmpty && _otpCodeController.text != null){
                                        _verifyOtp(_otpCodeController.text);
                                      }else{
                                        Fluttertoast.showToast(msg: 'Fill Otp', backgroundColor: Colors.black.withOpacity(0.7));
                                      }

                                    }else{
                                      Fluttertoast.showToast(msg: 'No Internet Connection', backgroundColor: Colors.black.withOpacity(0.7));
                                    }
                                    },
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[
                                        Container(
                                            margin: EdgeInsets.only(right: 20),
                                            child: Text(MyString.txt_get_otp,style: TextStyle(color: Colors.white),)),
                                        Image.asset('images/send_otp.png', width: 25, height: 25,)
                                      ],
                                    ),
                                      color: MyColor.colorPrimary,
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                //tv version
                Padding(
                  padding: EdgeInsets.only(bottom: 20.0),
                  child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Text("Version 1.0", style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextGrey),)),
                ),
              ],
            ),
          ),
        )
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }
}

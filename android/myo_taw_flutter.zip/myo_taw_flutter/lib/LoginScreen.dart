import 'package:flutter/material.dart';
import 'package:libphonenumber/libphonenumber.dart';
import 'helper/MyoTawConstant.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'main.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:dio/dio.dart';
import 'helper/ServiceHelper.dart';
import 'model/UserModel.dart';
import 'package:connectivity/connectivity.dart';
import 'helper/SharePreferencesHelper.dart';
import 'package:myotaw/Database/UserDb.dart';
import 'OtpScreen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  List<String> _cityList;
  String _dropDownCity = 'နေရပ်ရွေးပါ', _regionCode, _platForm , _normalizedPhNo;
  bool _isInitialized, _showLoading = false;
  bool _isCon = false;
  Response response;
  UserModel _userModel;
  Sharepreferenceshelper _sharePrefHelper = new Sharepreferenceshelper();
  UserDb _userDb = UserDb();
  TextEditingController _phoneNoController = new TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _cityList = [_dropDownCity,MyString.TGY_CITY,MyString.MLM_CITY];
    //initAccountkit();
    _sharePrefHelper.initSharePref();
  }

  void _getOtp()async{
    setState(() {
      _showLoading = true;
    });
    response = await ServiceHelper().getOtpCode(_normalizedPhNo, '+jhfkld4a');
    var result = response.data;
    setState(() {
      _showLoading = false;
    });
    if(response.statusCode == 200){
      if(result != null){
        if(result['code'] == '002'){
          Navigator.push(context, MaterialPageRoute(builder: (context) => OtpScreen(_normalizedPhNo, _regionCode)));
        }
      }else{
        Fluttertoast.showToast(msg: 'နောက်တစ်ကြိမ်လုပ်ဆောင်ပါ။', backgroundColor: Colors.black.withOpacity(0.7));
      }
    }else{
      Fluttertoast.showToast(msg: 'နောက်တစ်ကြိမ်လုပ်ဆောင်ပါ။', backgroundColor: Colors.black.withOpacity(0.7));
    }
  }

  _checkCon()async{
    var conResult = await(Connectivity().checkConnectivity());
    if (conResult == ConnectivityResult.none) {
      _isCon = false;
    }else{
      _isCon = true;
    }
    print('isCon : ${_isCon}');
  }

  Widget modalProgressIndicator(){
    return Center(
      child: Card(
        child: Container(
          width: 220.0,
          height: 80.0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(margin: EdgeInsets.only(right: 30.0),
                  child: Text('Loading......',style: TextStyle(fontSize: FontSize.textSizeNormal, color: Colors.black))),
              CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(MyColor.colorPrimary))
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _checkPhNoValid() async{
    bool _isValid = false;
    _normalizedPhNo = await PhoneNumberUtil.normalizePhoneNumber(phoneNumber: _phoneNoController.text, isoCode: 'MM');
    _isValid = await PhoneNumberUtil.isValidPhoneNumber(phoneNumber: _phoneNoController.text, isoCode: 'MM');

    return _isValid && !_normalizedPhNo.contains('+951');
  }

  /*Future<String> _normalizedPhNo() async{
    return await PhoneNumberUtil.normalizePhoneNumber(phoneNumber: _phoneNoController.text, isoCode: 'MM');
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: ModalProgressHUD(
          inAsyncCall: _showLoading,
          progressIndicator: modalProgressIndicator(),
          child: Center(
            child: Stack(
              children: <Widget>[
                //color primary bg
                Container(
                  color: MyColor.colorPrimary,
                  width: double.maxFinite,
                  height: 300,
                ),
                //login card
                Container(
                  width: double.maxFinite,
                  margin: EdgeInsets.only(bottom: 50),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.asset("images/myotaw_icon_white.png", width: 90, height: 80,),
                      Container(
                        margin: EdgeInsets.all(30),
                        child: Card(
                          child: Container(
                            margin: EdgeInsets.all(30),
                            child: Column(
                              children: <Widget>[
                                Container(
                                    margin: EdgeInsets.only(bottom: 30),
                                    child: Text(MyString.txt_welcome, style: TextStyle(fontSize: FontSize.textSizeExtraNormal, color: MyColor.colorPrimary), textAlign: TextAlign.center,)),
                                Container(
                                  decoration: BoxDecoration(
                                      border: Border.all(color: MyColor.colorPrimary, width: 1.0),
                                      borderRadius: BorderRadius.all(Radius.circular(10.0))
                                  ),
                                  margin: EdgeInsets.only(bottom: 20),
                                  padding: EdgeInsets.only(left: 15, right: 15),
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton<String>(
                                      style: new TextStyle(fontSize: 13.0, color: Colors.black87),
                                      isExpanded: true,
                                      icon: Icon(Icons.location_city),
                                      iconEnabledColor: MyColor.colorPrimary,
                                      value: _dropDownCity,
                                      onChanged: (String value){
                                        setState(() {
                                          _dropDownCity = value;
                                        });
                                      },
                                      items: _cityList.map<DropdownMenuItem<String>>((String str){
                                        return DropdownMenuItem<String>(
                                          value: str,
                                          child: Text(str),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(bottom: 30.0),
                                  padding: EdgeInsets.only(left: 10.0, right: 10.0),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(7.0),
                                      border: Border.all(color: MyColor.colorPrimary, style: BorderStyle.solid, width: 0.80)
                                  ),
                                  child: TextField(
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      suffixIcon: Icon(Icons.phone, color: MyColor.colorPrimary,),
                                      hintText: '09xxxxxx',
                                    ),
                                    cursorColor: MyColor.colorPrimary,
                                    controller: _phoneNoController,
                                    style: TextStyle(fontSize: FontSize.textSizeNormal, color: MyColor.colorTextBlack,),
                                    keyboardType: TextInputType.phone,
                                  ),
                                ),
                                Container(
                                  width: double.maxFinite,
                                  height: 45.0,
                                  child: RaisedButton(onPressed: () async{
                                    if(_dropDownCity != 'နေရပ်ရွေးပါ' && _phoneNoController.text.isNotEmpty){
                                      await _checkCon();
                                      if(_isCon){
                                        switch(_dropDownCity){
                                          case MyString.TGY_CITY:
                                            _regionCode = MyString.TGY_REGIONCODE;
                                            break;
                                          case MyString.MLM_CITY:
                                            _regionCode = MyString.MLM_REGIONCODE;
                                            break;
                                          default:
                                        }
                                        bool _isValid = await _checkPhNoValid();
                                        if(_isValid){
                                          _getOtp();
                                          //Navigator.push(context, MaterialPageRoute(builder: (context) => OtpScreen(_normalizedPhNo, _regionCode)));
                                        }else{
                                          Fluttertoast.showToast(msg: 'Invalide phone number', backgroundColor: Colors.black.withOpacity(0.7));
                                        }
                                      }else{
                                        Fluttertoast.showToast(msg: 'No Internet Connection', backgroundColor: Colors.black.withOpacity(0.7));
                                      }
                                    }else{
                                      Fluttertoast.showToast(msg: 'Please Choose City', backgroundColor: Colors.black.withOpacity(0.7));
                                    }
                                    },
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: <Widget>[
                                        Container(
                                            margin: EdgeInsets.only(right: 20),
                                            child: Text(MyString.txt_get_otp,style: TextStyle(color: Colors.white),)),
                                        Image.asset('images/get_otp.png', width: 25, height: 25,)
                                      ],
                                    ),
                                      color: MyColor.colorPrimary,
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                //tv version
                Padding(
                  padding: EdgeInsets.only(bottom: 20.0),
                  child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Text("Version 1.0", style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextGrey),)),
                ),
              ],
            ),
          ),
        )
    );
  }
}

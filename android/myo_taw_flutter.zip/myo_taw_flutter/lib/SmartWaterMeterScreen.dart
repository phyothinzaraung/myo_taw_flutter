import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:myotaw/model/SmartWaterMeterUnitModel.dart';
import 'helper/MyoTawConstant.dart';
import 'model/SmartWaterMeterUnitModel.dart';
import 'package:dio/dio.dart';
import 'helper/SharePreferencesHelper.dart';
import 'package:async_loader/async_loader.dart';
import 'helper/ServiceHelper.dart';
import 'model/PaymentLogModel.dart';
import 'helper/NumConvertHelper.dart';
import 'Database/UserDb.dart';
import 'model/UserModel.dart';
import 'TopUpScreen.dart';
import 'PinCodeSetUpScreen.dart';
import 'PaymentScreen.dart';
import 'model/SmartWaterMeterLogModel.dart';
import 'helper/ShowDateTimeHelper.dart';

class SmartWaterMeterScreen extends StatefulWidget {
  @override
  _SmartWaterMeterScreenState createState() => _SmartWaterMeterScreenState();
}

class _SmartWaterMeterScreenState extends State<SmartWaterMeterScreen> {
  final GlobalKey<AsyncLoaderState> asyncLoaderState = new GlobalKey<AsyncLoaderState>();
  bool _isCon;
  Response _responseWaterMeterUnit, _responseWaterMeterLog;
  int _amount,_finalUnit = 0;
  String _name, _meterNo;
  Sharepreferenceshelper _sharepreferenceshelper = Sharepreferenceshelper();
  SmartWaterMeterUnitModel _smartWaterMeterUnitModel;
  UserDb _userDb = UserDb();
  UserModel _userModel;
  List<SmartWaterMeterLogModel> _smartWaterMeterLogList = new List<SmartWaterMeterLogModel>();
  bool _isRefresh = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  _checkCon()async{
    var conResult = await(Connectivity().checkConnectivity());
    if (conResult == ConnectivityResult.none) {
      _isCon = false;
    }else{
      _isCon = true;
    }
    print('isCon : ${_isCon}');
  }

  _getWaterMeterUnit()async{
    await _sharepreferenceshelper.initSharePref();
    _responseWaterMeterUnit = await ServiceHelper().getSmartWaterMeterUnit(_sharepreferenceshelper.getUserPhoneNo());
    if(_responseWaterMeterUnit.data != null){
      _smartWaterMeterUnitModel = SmartWaterMeterUnitModel.fromJson(_responseWaterMeterUnit.data);
      _meterNo = _smartWaterMeterUnitModel.meterNo;
      _finalUnit = _smartWaterMeterUnitModel.finalUnit;
    }
  }

  _getSmartWaterMeterLog()async{
    _responseWaterMeterLog = await ServiceHelper().getSmartWaterMeterLog(_sharepreferenceshelper.getUserPhoneNo());
    _amount = _responseWaterMeterLog.data['Amount'];
     var list = _responseWaterMeterLog.data['Log'];
    for(var i in list){
      setState(() {
        _smartWaterMeterLogList.add(SmartWaterMeterLogModel.fromJson(i));
      });
    }
  }

  _getUser()async{
    await _sharepreferenceshelper.initSharePref();
    await _userDb.openUserDb();
    var model = await _userDb.getUserById(_sharepreferenceshelper.getUserUniqueKey());
    await _userDb.closeUserDb();
    setState(() {
      _userModel = model;
    });
    _name = _userModel.name;
    await _getWaterMeterUnit();
    if(_responseWaterMeterUnit.data != null){
      await _getSmartWaterMeterLog();
    }
    setState(() {
      _isRefresh = false;
    });
  }

  _navigateToTopUpScreen()async{
    Map result = await Navigator.of(context).push(MaterialPageRoute(builder: (context) => TopUpScreen(_userModel)));
    if(result != null && result.containsKey('isNeedRefresh') == true){
      _handleRefresh();
    }
  }

  _navigateToPinCodeSetUpScreen()async{
    Map result = await Navigator.of(context).push(MaterialPageRoute(builder: (context) => PinCodeSetUpScreen(_userModel)));
    if(result != null && result.containsKey('isNeedRefresh') == true){
      _handleRefresh();
    }
  }

  Widget _header(){
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 15.0, bottom: 15.0,left: 30.0, right: 30.0),
            child: Row(
              children: <Widget>[
                Container(
                    margin: EdgeInsets.only(right: 10.0),
                    child: Image.asset('images/online_tax_no_circle.png', width: 30.0, height: 30.0,)),
                Text(MyString.txt_smart_water_meter, style: TextStyle(fontSize: FontSize.textSizeSmall),)
              ],
            ),
          ),
          Container(
            width: double.maxFinite,
            height: 520.0,
            child: Card(
              margin: EdgeInsets.only(left: 20.0, right: 20.0, bottom: 20.0),
              color: MyColor.colorPrimary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
              child: Container(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.only(bottom: 20.0),
                      child: CircleAvatar(
                        backgroundImage: _userModel.photoUrl==null?AssetImage('images/profile_placeholder.png'):
                        NetworkImage(BaseUrl.USER_PHOTO_URL+_userModel.photoUrl),
                        backgroundColor: MyColor.colorGrey,
                        radius: 45.0,
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(bottom: 10),
                        child: Text(_name, style: TextStyle(fontSize: FontSize.textSizeNormal, color: Colors.white),)),
                    Container(
                      margin: EdgeInsets.only(bottom: 10),
                      child: Divider(
                        height: 1,
                        color: Colors.white,
                        thickness: 1.5,
                      ),
                    ),
                    Text(MyString.txt_user_money, style: TextStyle(fontSize: FontSize.textSizeNormal, color: Colors.white),),
                    Container(
                      margin: EdgeInsets.only(bottom: 10),
                      child: Row(
                         mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(right: 10),
                              child: Image.asset('images/money.png', width: 35, height: 35,)),
                          Text(NumConvertHelper().getMyanNumInt(_amount)+' '+MyString.txt_kyat, style: TextStyle(fontSize: FontSize.textSizeLarge, color: Colors.white),),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(bottom: 10),
                        child: Text(MyString.txt_water_meter_unit, style: TextStyle(fontSize: FontSize.textSizeNormal, color: Colors.white),)),
                    Container(
                      margin: EdgeInsets.only(bottom: 20),
                      child: Text(_finalUnit.toString(),
                        style: TextStyle(fontSize: FontSize.textSizeLarge, color: Colors.white),),
                    ),
                    Container(
                      margin: EdgeInsets.only(bottom: 10),
                      child: Divider(
                        height: 1,
                        color: Colors.white,
                        thickness: 1.5,
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(bottom: 30),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: Text(MyString.txt_water_meter_no,
                              style: TextStyle(fontSize: FontSize.textSizeNormal, color: Colors.white),),
                          ),
                          Expanded(
                            child: Text(_meterNo,
                              style: TextStyle(fontSize: FontSize.textSizeNormal, color: Colors.white),),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 2.5),
                      height: 45.0,
                      width: double.maxFinite,
                      child: RaisedButton(onPressed: ()async{
                        if(_userModel.pinCode != 0){
                          _navigateToTopUpScreen();
                        }else{
                          _navigateToPinCodeSetUpScreen();
                        }
                        }, child: Text(MyString.txt_top_up, style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorPrimary),),
                        color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),),
                    ),
                  ],
                ),
              ),
            ),
          )

        ],
      ),
    );
  }

  _listView(){
    return ListView.builder(
        itemCount: _smartWaterMeterLogList.length,
        itemBuilder: (context, index){
          return Column(children: <Widget>[
            index == 0? _header() : Container(),
            Card(
              margin: EdgeInsets.all(0.5),
              elevation: 0,
              child: Container(
                padding: EdgeInsets.all(20.0),
                  child: Row(
                    children: <Widget>[
                      Container(
                          margin: EdgeInsets.only(right: 20.0),
                          child: Image.asset('images/payment_history.png', width: 30.0, height: 30.0,)),
                      Expanded(
                        child: Column(
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(child: Text(MyString.txt_smart_wm_date, style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextBlack),)),
                                Expanded(child: Text(showDateTimeFromServer(_smartWaterMeterLogList[index].date), style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextBlack),))
                              ],
                            ),
                            Row(
                              children: <Widget>[
                                Expanded(child: Text(MyString.txt_smart_wm_unit, style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextBlack),)),
                                Expanded(child: Text(_smartWaterMeterLogList[index].unit.toString(), style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextBlack),))
                              ],
                            ),
                            Row(
                              children: <Widget>[
                                Expanded(child: Text(MyString.txt_smart_wm_amount, style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextBlack),)),
                                Expanded(child: Text(_smartWaterMeterLogList[index].amount.toString()+'  '+MyString.txt_kyat, style: TextStyle(fontSize: FontSize.textSizeSmall, color: MyColor.colorTextBlack),))
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  )
              ),
            )
          ],);
        });
  }

  Widget getNoConnectionWidget(){
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text('No Internet Connection'),
                  FlatButton(onPressed: (){
                    asyncLoaderState.currentState.reloadState();
                    _checkCon();
                  }
                    , child: Text('Retry', style: TextStyle(color: Colors.white),),color: MyColor.colorPrimary,)
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _renderLoad(){
    return Container(
      margin: EdgeInsets.only(top: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(mainAxisAlignment: MainAxisAlignment.center,children: <Widget>[CircularProgressIndicator()],)
        ],
      ),
    );
  }

  Future<Null> _handleRefresh() async {
    await _checkCon();
    setState(() {
      _isRefresh = true;
    });
    if(_isCon){
      setState(() {
        _smartWaterMeterLogList.clear();
      });
      _getUser();
    }else{
      Fluttertoast.showToast(msg: 'Check Connection', backgroundColor: Colors.black.withOpacity(0.7), fontSize: FontSize.textSizeSmall);
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    var _asyncLoader = new AsyncLoader(
        key: asyncLoaderState,
        initState: () async => await _getUser(),
        renderLoad: () => _renderLoad(),
        renderError: ([error]) => getNoConnectionWidget(),
        renderSuccess: ({data}) => Container(
          child: RefreshIndicator(
              onRefresh: _handleRefresh,
              child: _responseWaterMeterUnit.data!=null?_isRefresh == false?_smartWaterMeterLogList.isNotEmpty?_listView() :
                  ListView(children: <Widget>[_header()],) :
              Container(
                margin: EdgeInsets.only(top: 10.0),
                child: Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[CircularProgressIndicator()],),
              ) : Container(
                padding: EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(bottom: 20),
                          child: Image.asset('images/warning.png', width: 70, height: 70,)),
                      Text(MyString.txt_smart_wm_not_register, style: TextStyle(fontSize: FontSize.textSizeNormal,),textAlign: TextAlign.center,)
                ],
              ))
          ),
        )
    );
    return Scaffold(
      appBar: AppBar(
        title: Text(MyString.txt_smart_water_meter, style: TextStyle(fontSize: FontSize.textSizeNormal),),
      ),
      body: _asyncLoader,
    );
  }
}

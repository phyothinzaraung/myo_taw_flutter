
import 'dart:ui';

class PieChartColorHelper{
  List<Color> defaultColorList = [
    Color.fromRGBO(255, 247, 137, 0.8),
    Color.fromRGBO(189, 255, 154, 0.8),
    Color.fromRGBO(170, 255, 220, 0.8),
    Color.fromRGBO(145, 184, 255, 0.8),
    Color.fromRGBO(224, 153, 255, 0.8),
    Color.fromRGBO(255, 131, 124, 0.8),
    Color.fromRGBO(255, 173, 125, 0.8),
    Color.fromRGBO(152, 255, 171, 0.8),
    Color.fromRGBO(141, 202, 255, 0.8),
    Color.fromRGBO(255, 133, 174, 0.8),
    ];
}